package hash;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;
import java.util.logging.FileHandler;
import java.util.logging.Formatter;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

public class Main {

    public static void main(String[] args)  {

        //储存结果


        Logger log = Logger.getLogger("log");
        log.setLevel(Level.ALL);
        //加载配置
        Properties property = new Properties();
        try {
            property.load(new FileInputStream("src/hash/conf.properties"));
        } catch (IOException e) {
            System.out.println("读取配置文件异常");
        }
        //获取时间间隔
        String timeStr = property.getProperty("time");
        int time = Integer.parseInt(timeStr);
        //获取节点数
        String nodeNumStr = property.getProperty("nodeNum");
        int nodeNum = Integer.parseInt(nodeNumStr);

        log.info("init config");
        log.info("time: " + time);
        log.info("nodeNum: " + nodeNum);

        //初始化所有节点
        log.info("init node");
        int Allticket = 0;
        Map<Integer,Node> nodes = new HashMap<>();
        for (int i = 0; i < nodeNum; i++){
            //获取地址
            String addr = HashUtil.getUUID();
            //票  取余10
            Node node = new Node(i,addr,i%10);
            Allticket += i%10;
            nodes.put(i,node);
        }

        //初始化创世快
        log.info("init Creation block");
        Block c = new Block();
        //随机生成3个hash
        String hash1 = HashUtil.getSHA256StrJava(HashUtil.getUUID());
        String hash2 = HashUtil.getSHA256StrJava(HashUtil.getUUID());
        String hash3 = HashUtil.getSHA256StrJava(HashUtil.getUUID());
        Vector<String> results1 = new Vector<>();
        results1.add(hash1);
        results1.add(hash2);
        results1.add(hash3);
        Map<Integer,String> hashs = HashUtil.getMinThree(results1,3);
        c.setMinHash(hashs.get(0));
        c.setMinHash(hashs.get(1));
        c.setMinHash(hashs.get(2));

        //创世块加入链
        log.info("join in chain");
        Chain chain = new Chain();
        Map<Integer, Block> blockMap = new HashMap<>();
        chain.setLastHeight(1);
        blockMap.put(chain.getLastHeight(),c);
        chain.setBlockMap(blockMap);

        System.out.println("start...");
        //开始
        while (true){
            //统计0的个数
            Result r = new Result();
            r.setZero(0);
            r.setOne(0);
            r.setTwo(0);
            r.setThree(0);
            r.setFore(0);
            r.setFive(0);
            r.setSix(0);
            r.setSeven(0);

            final Vector<String> results = new Vector<>();
            final CountDownLatch latch = new CountDownLatch(nodes.size());

            String nineHash = chain.GetHash();
            //遍历节点
            System.out.println("waiting......");
            for (int i = 0;i < nodes.size(); i++){
                Node n = nodes.get(i);
                n.setLatch(latch);
                n.setNineHash(nineHash);
                n.setTime(time);
                n.setResults(results);
                n.setZeroResult(r);
                Thread t = new Thread(n);
                t.start();
            }


            //等待所有线程执行完
            try {
                latch.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            //获取最小的3个hash
            Map<Integer,String> mins = HashUtil.getMinThree(results,10);
            System.out.println("------------------------------------------");
            for (int i = 0; i < 10; i++){
                System.out.println(mins.get(i));
            }
            //创建块
            Block b = new Block();
            b.setMinHash(mins.get(0));
            b.setMediumHash(mins.get(1));
            b.setLargeHash(mins.get(2));
            b.setHeight(chain.getLastHeight()+1);
            //加入链
            chain.setLastHeight(chain.getLastHeight()+1);
            Map<Integer, Block> bkm = chain.getBlockMap();
            bkm.put(chain.getLastHeight(),b);
            chain.setBlockMap(bkm);


            System.out.println("height: "+b.getHeight());
            System.out.println("MinHas: "+b.getMinHash());
            System.out.println("MediumHash: "+b.getMediumHash());
            System.out.println("LargeHash: "+b.getLargeHash());
            System.out.println(r);

        }
    }
}
