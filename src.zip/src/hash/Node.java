package hash;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.util.concurrent.CountDownLatch;

public class Node implements Runnable {

    private Integer name;
    private String address;
    private Integer power;
    private Integer time;//时间间隔
    private String nineHash;
    private CountDownLatch latch;//线程计数器
    private Vector<String> results;
    private  Result zeroResult;

    public Result getZeroResult() {
        return zeroResult;
    }

    public void setZeroResult(Result zeroResult) {
        this.zeroResult = zeroResult;
    }

    public Node(Integer name, String address, Integer power) {
        this.name = name;
        this.address = address;
        this.power = power;
    }

    public Vector<String> getResults() {
        return results;
    }

    public void setResults(Vector<String> results) {
        this.results = results;
    }

    public CountDownLatch getLatch() {
        return latch;
    }

    public void setLatch(CountDownLatch latch) {
        this.latch = latch;
    }

    public Integer getTime() {
        return time;
    }

    public void setTime(Integer time) {
        this.time = time;
    }

    public String getNineHash() {
        return nineHash;
    }

    public void setNineHash(String nineHash) {
        this.nineHash = nineHash;
    }

    public Integer getName() {
        return name;
    }

    public void setName(Integer name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getPower() {
        return power;
    }

    public void setPower(Integer power) {
        this.power = power;
    }

    @Override
    public void run() {
        long millis = System.currentTimeMillis();




        String min = HashUtil.getSHA256StrJava(address + 0 + 0 + nineHash);
        for (int i = 0; i < power; i ++){
            for (int j = 0; j < time; j ++){
                long time1 = millis + j;
                String target = address + i + time1 + nineHash;
                String result = HashUtil.getSHA256StrJava(target);

                //统计0的情况
                zeroResult.findZero(zeroResult,result);

                if (result.compareTo(min) < 0){
                    min = result;
                }
            }
        }

        results.add(min);
        latch.countDown();
    }
}
